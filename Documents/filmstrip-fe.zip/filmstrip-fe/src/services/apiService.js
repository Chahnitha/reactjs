const BASE_URL = "http://localhost:4000";

export const _mockData = async () => {
  let response = await fetch('data/templates.json', {
    method: "GET",
  });
  return response.json();
};

export const _getData = async () => {
  const dataUrl = BASE_URL  + "/data";
  let response = await fetch(dataUrl, {
    method: "GET",
    headers: { "Content-type": "application/json; charset=UTF-8" },
  });
  return response.json();
};