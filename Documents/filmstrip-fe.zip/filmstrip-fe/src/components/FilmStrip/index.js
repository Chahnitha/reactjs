import React from 'react';
import { _getData } from '../../services/apiService';

export default function FilmStrip() {
  const [data, setData] = React.useState(null);
  const [currentData, setCurrentData] = React.useState(null);
  const [selectedImageIndex, setSelectedImageIndex] = React.useState(null);
  const [selectedImageMetadata, setSelectedImageMetadata] = React.useState(null);
  const [currentPage, setCurrentPage] = React.useState(null);
  const [hasPrevious, setHasPrevious] = React.useState(false);
  const [hasNext, setHasNext] = React.useState(false);

  const selectImage = index => {
      setSelectedImageMetadata(currentData[index]);
      setSelectedImageIndex(index);
  };

  const moveWindow = async type => {
    let findCurrentData;
    let newCurrentPage;
      if(type==='next') {
        findCurrentData = data.slice(currentPage*4, (currentPage+1)*4);
        newCurrentPage = currentPage+1;
      } else {
        findCurrentData = data.slice((currentPage-2)*4, (currentPage-1)*4);
        newCurrentPage = currentPage-1;
      }
      setCurrentPage(newCurrentPage);
      setCurrentData(findCurrentData);
      setHasNext(data.length>(newCurrentPage*4));
      setHasPrevious(newCurrentPage>1);
      setSelectedImageMetadata(findCurrentData[0]);
      setSelectedImageIndex(0);
  };

  React.useEffect(() => {
    async function fetchData() {
      let result = await _getData();
      // select first data
      setCurrentPage(1);
      setSelectedImageMetadata(result[0]);
      setCurrentData(result.length>4? result.slice(0, 4): result);
      setHasNext(result.length>4);
      setSelectedImageIndex(0);
      setData(result);
    }
    fetchData();
  }, []);

  return (
    <div>
    {data?<div><header>
    Code Development Project
    </header>
    <div id="main" role="main">
    <div id="large">
      <div className="group">
        <img src={'/images/large/'+selectedImageMetadata.image} alt="Main" width="430" height="360" />
        <div className="details">
          <p><strong>Title</strong> {selectedImageMetadata.title}</p>
          <p><strong>Description</strong> {selectedImageMetadata.description}</p>
          <p><strong>Cost</strong> ${selectedImageMetadata.cost}</p>
          <p><strong>ID #</strong> {selectedImageMetadata.id}</p>
          <p><strong>Thumbnail File</strong> {selectedImageMetadata.thumbnail}</p>
          <p><strong>Large Image File</strong> {selectedImageMetadata.image}</p>
        </div>
      </div>
    </div>
    <div className="thumbnails">
      <div className="group">
        {currentData.map((data,index)=> (
 <button  onClick={() => selectImage(index)} className={` ${
          index===selectedImageIndex ? "active" : ""
        }`} key={index}>
          <img src={'images/thumbnails/'+data.thumbnail} alt={data.thumbnail} width="145" height="121" />
          <span>{data.id}</span>
        </button>))
        }
     
        <span className={`previous ${
          !hasPrevious ? "disabled" : ""
        }`} title="Previous" onClick={() => hasPrevious && moveWindow('prev')} disabled={!hasPrevious} >Previous</span>
        <span className={`next ${
          !hasNext ? "disabled" : ""
        }`} title="Next" disabled={!hasNext} onClick={() => hasNext &&  moveWindow('next')}>Next</span>
      </div>
    </div>
    </div></div>:'Loading...'}
    
    </div>
  );
}