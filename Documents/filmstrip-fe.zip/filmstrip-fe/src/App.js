import './App.css';
import FilmStrip from "./components/FilmStrip";

function App() {
  return (
    <div id="container">
    <FilmStrip />
  </div>
  );
}

export default App;
